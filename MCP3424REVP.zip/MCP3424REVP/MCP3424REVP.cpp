/* MCP3424 library version 1.3

Writed by B@tto
Contact : batto@hotmail.fr


  MCP3424.cpp - ADC 18 bits i2c library for Wiring & Arduino
  Copyright (c) 2012 Yann LEFEBVRE.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
  Revised by Muhammad Nurul Puji
  MCP3424REVP library is revision version of original MCP 3424 version 1.3
  MCP3424REVP library is optimized for negative voltage measurement (in 12, 14, 16 and 18 bits) and positive voltage measurement (in 12 and 14 bits)
  improve for negative value by using two complement's (from 24 or 16 bits to Long data type - 32 bits)
  muhammadpuji.its@gmail.com
*/

#include "MCP3424REVP.h"

MCP3424REVP::MCP3424REVP(uint8_t adresse){

_adresse=0b1101<<3;		//kode MCP3424 sesuai datasheet fabrikasi 1101
_adresse|=adresse;



}

MCP3424REVP::~MCP3424REVP(){

}

void MCP3424REVP::begin(byte setMod){

#ifdef ENERGIA
Wire.setModule(setMod);
#endif

Wire.begin();

}

void MCP3424REVP::configuration(uint8_t channel,uint8_t resolution,bool mode,uint8_t PGA){

if(resolution!=12 && resolution!=14 && resolution!=16 && resolution!=18) _resolution=12;
 else _resolution=resolution;

_PGA=PGA;
_mode=mode;

_cfgbyte=0;
_cfgbyte |= ((channel-1) & 0x3) << 5;
_cfgbyte |= (mode & 0x1) << 4;
_cfgbyte |= (int((_resolution-12)/2) & 0x3) << 2;
_cfgbyte |= (int(logf(PGA)/logf(2))) & 0x3;

Wire.beginTransmission(_adresse);
Wire.write(_cfgbyte);
Wire.endTransmission();

}

void MCP3424REVP::newConversion(){

Wire.beginTransmission(_adresse);
Wire.write((_cfgbyte|=128));
Wire.endTransmission();

}

bool MCP3424REVP::isConversionFinished(){

uint8_t _requestedByte;

if(_resolution!=18){
_requestedByte = 3;
} else _requestedByte = 4;

Wire.requestFrom(_adresse, _requestedByte);

uint8_t _i=0;

while(Wire.available()) _buffer[_i++]=Wire.read();

return (_buffer[_requestedByte-1] & 0b10000000);	//0b10000000 karena ~RDY (0 berarti ready) berada pada bit pertama dari _buffer[_requestedByte-1]

}


long MCP3424REVP::measure(){

long _resultat=0;

while(isConversionFinished()==1);

switch (_resolution){

case 12:
 if ((_buffer[0] & 0x80)==0x80){		//Revisi ini digunakan untuk mengakali negative (two's complement) dari 24 bits ke 32 bits (karena long 32 bits)
	_resultat = 0xFFFF0000 | (((long)_buffer[0] & 0xFF) << 8) | ((long)_buffer[1] & 0xFF);
	//_resultat = (-1) - _resultat + (-2047) ;
}else{
	_resultat = (((long)_buffer[0] & 0x07) << 8) | ((long)_buffer[1] & 0xFF); 	//0x07 (0b00000111) karena magnitute dimulai bit ke 11 (atau bit ke 3 pada byte pertama)
 
	//_resultat |= long(_buffer[0] & 0x80) << 24;	//ini belom tahu
}
 _resultat = _resultat*1000.0/_PGA;

 break;

case 14:
 if ((_buffer[0] & 0x80)==0x80){		//Revisi ini digunakan untuk mengakali negative (two's complement) dari 24 bits ke 32 bits (karena long 32 bits)
	_resultat = 0xFFFF0000 | (((long)_buffer[0] & 0xFF) << 8) | ((long)_buffer[1] & 0xFF);
	//_resultat = (-1) - _resultat + (-8191) ;
}else{
	_resultat = (((long)_buffer[0] & 0x1F) << 8) | ((long)_buffer[1] & 0xFF); 	//0x1F (0b00011111) karena magnitute dimulai bit ke 13 (atau bit ke 5 pada byte pertama)

	//_resultat |= long(_buffer[0] & 0x80) << 24;		//ini belom tahu
}
_resultat = _resultat*250/_PGA;

 break;

case 16:

if ((_buffer[0] & 0x80)==0x80){		//Revisi ini digunakan untuk mengakali negative (two's complement) dari 24 bits ke 32 bits (karena long 32 bits)
	_resultat = 0xFFFF0000 | (((long)_buffer[0] & 0xFF) << 8) | ((long)_buffer[1] & 0xFF);
	//_resultat = (-1) - _resultat + (-32767) ;
}else{
	_resultat = (((long)_buffer[0] & 0x7F) << 8) | ((long)_buffer[1] & 0xFF); 	//0x7F (0b01111111) karena magnitute dimulai bit ke 15 (atau bit ke 7 pada byte pertama)

	//_resultat |= long(_buffer[0] & 0x80) << 24;	//ini belom tahu
}
_resultat = _resultat*62.5/_PGA;

 break;

case 18:

if ((_buffer[0] & 0x80)==0x80){		//Revisi ini digunakan untuk mengakali negative (two's complement) dari 24 bits ke 32 bits (karena long 32 bits)
	_resultat = 0xFF000000 | (((long)_buffer[0] & 0xFF) << 16) | (((long)_buffer[1] & 0xFF) <<8) | ((long)_buffer[2] & 0xFF);
	//_resultat = (-1) - _resultat + (-131071) ;	//ini karena urutannya terbalik (hanya di simulasi proteus), seharusnya dari -1 ke -131072 (atau -131071 karena ada nilai 0)
}else{
	_resultat = (((long)_buffer[0] & 0x01) << 16) | (((long)_buffer[1] & 0xFF) <<8) | ((long)_buffer[2] & 0xFF);	//0x01 (0b00000001) karena magnitute dimulai bit ke 17 (atau bit ke 1 pada byte pertama)

	//_resultat |=((long)_buffer[0] & 0x80) << 24;	//sepertinya ini digunakan untuk mengakali negative (two complement's) dari 24 bits ke 32 bits (karena long 32 bits)
												//tapi salah (completely wrong)
}
_resultat = _resultat*15.625/_PGA;

  break;
}

return _resultat;

}

