/* MCP3424 library version 1.3

Writed by B@tto 
Contact : batto@hotmail.fr


  MCP3424.h - ADC 18 bits i2c library for Wiring & Arduino
  Copyright (c) 2012 Yann LEFEBVRE.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
  Edited by Muhammad Nurul Puji
  improve for negative value by using two complement's (from 24 or 16 bits to Long data type - 32 bits)
  muhammadpuji.its@gmail.com
*/

#ifndef MCP3424REVP_H
#define MCP3424REVP_H

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include <Wire.h>
#include <Math.h>

class MCP3424REVP {

public:

MCP3424REVP(uint8_t adresse);
~MCP3424REVP();
void begin(byte setMod = 1);
void configuration(uint8_t channel,uint8_t resolution,bool mode,uint8_t PGA);
void newConversion();
bool isConversionFinished();
long measure();

private:

uint8_t _adresse;
uint8_t _resolution;
bool _mode;
uint8_t _cfgbyte;
uint8_t _PGA;
uint8_t _buffer[4];

};

#endif
